//
//  KMLConst.h
//  KML Framework
//
//  Created by NextBusinessSystem on 12/04/06.
//  Copyright (c) 2012 NextBusinessSystem Co., Ltd. All rights reserved.
//

extern NSString *const kKMLInvalidKMLFormatNotification;
extern NSString *const kKMLDescriptionKey;
